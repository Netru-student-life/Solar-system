let a= prompt("Enter the roll number");
a = parseInt(a);
switch (a){
case 1:
    document.write(" Vaibhav Kumar");
    break;
case 2:
    document.write("Saloni Tiwari");
    break;
case 3:
    document.write("Samrin");
    break;
case 4:
    document.write("Saloni Kumari");
    break;
case 5:
    document.write("Anjani porwal");
    break;
case 6:
    document.write("Khusi Sharma");
    break;
case 7:
    document.write("Sumit 2nd");
    break;
case 8:
    document.write("Akanksha");
    break;
case 9:
    document.write("Suraj");
    break;
case 10:
    document.write("Dhruv");
    break;
case 11:
    document.write("Dhruv Prakahs");
    break;
case 12:
    document.write("Prinshu");
    break;
case 13:
    document.write("Aditya Roy");
    break;
case 14:
    document.write("Shiva Gupta");
    break;
case 15:
    document.write("Mohit Sharma");
    break;
case 16:
    document.write("Himanshu rajput");
    break;
case 17:
    document.write("Abhisekh Ghupta");
    break;
case 18:
    document.write("Lavi");
    break;
case 19:
    document.write("Neelam");
    break;
case 20:
    document.write("Laxmi");
    break;
case 21:
    document.write("Rajkumar");
    break;
case 22:
    document.write("Vaishnavi");
    break;
case 23:
    document.write("Abhi Bharat Dhvuj");
    break;
case 24:
    document.write("jaychandra");
    break;
case 25:
    document.write("Rakhi");
    break;
case 26:
    document.write("Shiv sagar singh");
    break;
case 27:
    document.write("utkarsh");
    break;
case 28:
    document.write("Anuj");
    break;
case 29:
    document.write("Arun jain");
    break;
case 30:
    document.write("shiwank");
    break;
case 31:
    document.write("*****");
    break;
case 32:
    document.write("*****");
    break;
case 33:
    document.write("*****");
    break;
case 34:
    document.write("*****");
    break;
case 35:
    document.write("*****");
    break;
case 36:
    document.write("*****");
    break;
case 37:
    document.write("*****");
    break;
case 38:
    document.write("*****");
    break;
case 39:
    document.write("*****");
    break;
case 40:
    document.write("*****");
    break;
case 41:
    document.write("*****");
    break;
case 42:
    document.write("*****");
    break;
case 43:
    document.write("*****");
    break;
case 45:
    document.write("Netrapal");
    break;
case 46:
    document.write("*****");
    break;
case 47:
    document.write("*****");
    break;
case 48:
    document.write("*****");
    break;
case 49:
    document.write("*****");
    break;
case 50:
    document.write("*****");
    break;
case 51:
    document.write("*****");
    break;
case 52:
    document.write("*****");
    break;
case 53:
    document.write("*****");
    break;
case 54:
    document.write("*****");
    break;
case 55:
    document.write("*****");
    break;
case 56:
    document.write("*****");
    break;
case 57:
    document.write("*****");
    break;
case 58:
    document.write("*****");
    break;
case 59:
    document.write("*****");
    break;
case 60:
    document.write("*****");
    break;
case 61:
    document.write("*****");
    break;
case 62:
    document.write("*****");
    break;
case 63:
    document.write("*****");
    break;
case 64:
    document.write("*****");
    break;
case 65:
    document.write("*****");
    break;
case 66:
    document.write("*****");
    break;
case 67:
    document.write("*****");
    break;
default:
    document.write("Invalid Roll Number");
    break;
}

